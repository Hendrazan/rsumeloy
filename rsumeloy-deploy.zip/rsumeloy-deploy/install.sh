#!/bin/bash

# ================================================
# SCRIPT INSTALL DI SERVER JAGOAN HOSTING
# ================================================
# Jalankan script ini via SSH setelah upload files
# chmod +x install.sh
# ./install.sh

echo "================================================"
echo "  Installing RSU Meloy Website"
echo "================================================"
echo ""

# Check Node.js version
echo "[1/6] Checking Node.js version..."
node_version=$(node -v)
echo "Node.js version: $node_version"
if [[ "$node_version" < "v18" ]]; then
    echo "❌ ERROR: Node.js v18+ required!"
    echo "Please upgrade Node.js first"
    exit 1
fi
echo "✅ Node.js version OK"
echo ""

# Install dependencies
echo "[2/6] Installing dependencies..."
echo "This may take 5-10 minutes..."
npm install --production
if [ $? -ne 0 ]; then
    echo "❌ ERROR: npm install failed!"
    exit 1
fi
echo "✅ Dependencies installed"
echo ""

# Build Next.js
echo "[3/6] Building Next.js application..."
echo "This may take 3-5 minutes..."
npm run build
if [ $? -ne 0 ]; then
    echo "❌ ERROR: Build failed!"
    exit 1
fi
echo "✅ Build completed"
echo ""

# Install PM2 globally
echo "[4/6] Installing PM2..."
if ! command -v pm2 &> /dev/null; then
    npm install -g pm2
    echo "✅ PM2 installed"
else
    echo "✅ PM2 already installed"
fi
echo ""

# Stop existing process if any
echo "[5/6] Stopping existing process..."
pm2 delete rsumeloy 2>/dev/null || true
echo "✅ Clean slate ready"
echo ""

# Start with PM2
echo "[6/6] Starting application with PM2..."
pm2 start npm --name "rsumeloy" -- start
pm2 save
pm2 startup
echo "✅ Application started"
echo ""

echo "================================================"
echo "  Installation Complete!"
echo "================================================"
echo ""
echo "Application is running on port 3000"
echo ""
echo "Useful commands:"
echo "  pm2 status          - Check status"
echo "  pm2 logs rsumeloy   - View logs"
echo "  pm2 restart rsumeloy - Restart app"
echo "  pm2 stop rsumeloy   - Stop app"
echo ""
echo "Next steps:"
echo "1. Setup reverse proxy (Nginx/Apache)"
echo "2. Configure SSL certificate"
echo "3. Test website: curl http://localhost:3000"
echo ""
