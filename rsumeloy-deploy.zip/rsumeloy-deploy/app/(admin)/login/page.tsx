
import LoginPage from "../../../components/admin/LoginPage";

export default function Login() {
  return <LoginPage />;
}
