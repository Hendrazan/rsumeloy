# 🚀 PANDUAN DEPLOY RSU MELOY KE JAGOAN HOSTING

## ✅ PERSIAPAN SELESAI!

Folder `rsumeloy-deploy` sudah berisi semua file yang diperlukan untuk production.

## 📦 ISI FOLDER DEPLOY

```
rsumeloy-deploy/
├── app/                    (Source code)
├── components/             (React components)
├── lib/                    (Libraries)
├── public/                 (Static files)
├── types/                  (TypeScript types)
├── data/                   (Data files)
├── supabase/               (Database config)
├── .env                    (Environment variables - SUDAH TERISI)
├── .htaccess               (Apache config)
├── nginx.conf              (Nginx config)
├── install.sh              (Auto install script)
├── package.json            (Dependencies)
├── next.config.mjs         (Next.js config)
└── ... (config files lainnya)
```

**Total size**: ~50-100 MB (tanpa node_modules)

---

## 🎯 LANGKAH DEPLOY

### STEP 1: Upload ke Hosting

#### Opsi A: Via FTP (FileZilla/WinSCP)

1. **Buka FileZilla atau FTP client lain**
2. **Connect ke server Jagoan Hosting**:
   - Host: Dari cPanel/email hosting
   - Username: username FTP Anda
   - Password: password FTP Anda
   - Port: 21

3. **Upload folder rsumeloy-deploy**:
   - Upload ke: `/home/username/public_html/` atau `/home/username/rsumeloy/`
   - Waktu upload: 10-30 menit (tergantung koneksi)

4. **Rename folder** (opsional):
   ```
   rsumeloy-deploy → rsumeloy
   ```

#### Opsi B: Via cPanel File Manager

1. **Login ke cPanel Jagoan Hosting**
2. **Buka File Manager**
3. **Navigate ke public_html**
4. **Klik Upload**
5. **Compress folder rsumeloy-deploy menjadi ZIP**:
   - Klik kanan folder → Send to → Compressed (zipped) folder
6. **Upload file ZIP**
7. **Extract di server**:
   - Klik kanan file ZIP → Extract

---

### STEP 2: Setup via SSH

#### 2.1 Connect SSH

```bash
# Dari terminal/command prompt
ssh username@your-server-ip

# Atau dari cPanel → Terminal
```

#### 2.2 Navigate ke Folder

```bash
cd ~/public_html/rsumeloy
# atau
cd ~/rsumeloy
```

#### 2.3 Jalankan Auto Install Script

```bash
# Berikan permission execute
chmod +x install.sh

# Jalankan script
./install.sh
```

Script akan otomatis:
- ✅ Check Node.js version
- ✅ Install dependencies (npm install)
- ✅ Build Next.js (npm run build)
- ✅ Install PM2
- ✅ Start aplikasi

**Estimasi waktu**: 10-15 menit

#### 2.4 Verifikasi

```bash
# Check status PM2
pm2 status

# Lihat logs
pm2 logs rsumeloy

# Test website
curl http://localhost:3000
```

---

### STEP 3: Setup Web Server (Nginx/Apache)

#### Opsi A: Nginx (Recommended)

1. **Copy config Nginx**:
```bash
sudo cp nginx.conf /etc/nginx/sites-available/rsumeloy.conf
```

2. **Edit domain** (jika perlu):
```bash
sudo nano /etc/nginx/sites-available/rsumeloy.conf
# Ganti rsumeloy.co.id dengan domain Anda
```

3. **Enable site**:
```bash
sudo ln -s /etc/nginx/sites-available/rsumeloy.conf /etc/nginx/sites-enabled/
```

4. **Test config**:
```bash
sudo nginx -t
```

5. **Reload Nginx**:
```bash
sudo systemctl reload nginx
```

#### Opsi B: Apache (Jika menggunakan cPanel)

File `.htaccess` sudah tersedia. Pastikan:

1. **Module mod_proxy enabled**:
```bash
sudo a2enmod proxy
sudo a2enmod proxy_http
sudo systemctl restart apache2
```

2. **Edit .htaccess** jika perlu port berbeda

---

### STEP 4: Setup SSL (HTTPS)

#### Via Certbot (Let's Encrypt - FREE)

```bash
# Install Certbot
sudo apt install certbot python3-certbot-nginx

# Generate SSL
sudo certbot --nginx -d rsumeloy.co.id -d www.rsumeloy.co.id

# Auto renewal
sudo certbot renew --dry-run
```

#### Via cPanel (Jika tersedia)

1. Login cPanel
2. SSL/TLS → Manage SSL Sites
3. Install SSL Certificate (AutoSSL atau Let's Encrypt)

---

### STEP 5: Test Website

1. **Buka browser**: https://rsumeloy.co.id
2. **Test features**:
   - ✅ Homepage load
   - ✅ AI Assistant (klik tombol robot)
   - ✅ WhatsApp button
   - ✅ APAM button
   - ✅ Halaman kontak
   - ✅ Jadwal dokter

---

## 🔧 TROUBLESHOOTING

### Problem: npm install error

```bash
# Clear cache
npm cache clean --force

# Install ulang
rm -rf node_modules package-lock.json
npm install --production
```

### Problem: Build failed

```bash
# Check Node.js version
node -v  # Harus v18+

# Check disk space
df -h

# Check memory
free -m  # Minimal 1GB RAM
```

### Problem: PM2 tidak bisa start

```bash
# Check port 3000
lsof -i :3000

# Kill process yang pakai port 3000
kill -9 $(lsof -t -i:3000)

# Start ulang
pm2 delete rsumeloy
pm2 start npm --name "rsumeloy" -- start
```

### Problem: Website tidak bisa diakses

```bash
# Check PM2 status
pm2 status

# Check logs
pm2 logs rsumeloy

# Check Nginx
sudo nginx -t
sudo systemctl status nginx

# Check firewall
sudo ufw status
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
```

### Problem: AI Assistant tidak jalan

```bash
# Check .env file
cat .env | grep GEMINI

# Pastikan ada GEMINI_API_KEY
# Jika tidak ada, edit .env:
nano .env
# Tambahkan: GEMINI_API_KEY=AIzaSyCtzR5ZX-r8YHwNgTjIhfYzFpEhtGmTLRc

# Restart PM2
pm2 restart rsumeloy
```

---

## 📊 MONITORING

### Check Status

```bash
# PM2 status
pm2 status

# Real-time monitoring
pm2 monit

# Logs
pm2 logs rsumeloy --lines 100

# Memory usage
pm2 info rsumeloy
```

### Setup Monitoring Dashboard

```bash
# Install PM2 plus (optional)
pm2 plus
# Follow instructions untuk monitoring dashboard
```

---

## 🔄 UPDATE/REDEPLOY

Untuk update website di masa depan:

### Via FTP:

1. Upload file yang berubah
2. SSH ke server:
   ```bash
   cd ~/rsumeloy
   npm run build
   pm2 restart rsumeloy
   ```

### Via Git (Recommended):

1. Setup git di server:
   ```bash
   cd ~/rsumeloy
   git init
   git remote add origin https://github.com/Hendra-zan/rsumeloy.git
   ```

2. Update:
   ```bash
   git pull origin master
   npm install --production
   npm run build
   pm2 restart rsumeloy
   ```

---

## 📋 CHECKLIST SEBELUM PRODUCTION

- [ ] Domain sudah pointing ke IP hosting
- [ ] Node.js v18+ terinstall
- [ ] Port 3000 tidak diblokir
- [ ] .env file sudah terisi semua
- [ ] npm run build sukses tanpa error
- [ ] PM2 status online
- [ ] Nginx/Apache reverse proxy configured
- [ ] SSL certificate installed
- [ ] Website bisa diakses via HTTPS
- [ ] AI Assistant berfungsi
- [ ] WhatsApp & APAM button berfungsi
- [ ] Semua halaman load dengan baik

---

## 🆘 SUPPORT

Jika ada masalah:

1. **Check logs PM2**: `pm2 logs rsumeloy`
2. **Check Nginx logs**: `sudo tail -f /var/log/nginx/error.log`
3. **Contact Jagoan Hosting support** untuk:
   - Node.js installation
   - SSH access
   - Firewall configuration

---

## 📞 KONTAK DARURAT

- **Jagoan Hosting Support**: https://www.jagoanhosting.com/support
- **cPanel**: https://cpanel.jagoanhosting.com
- **Domain Management**: Login cPanel → Domains

---

## ✅ SELESAI!

Website RSU Meloy siap production! 🎉

**URL Production**: https://rsumeloy.co.id
